
package com.tis.mx.application.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * The Class InvestmentYieldDto.
 */
@Getter
@Setter
public class InvestmentYieldDto {

}
