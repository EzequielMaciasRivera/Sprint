package com.tis.mx.application.dto;

public class InitialInvestmentDto {
  
}
